{
  "schema": "PROOVRA_SIGNED_PACKAGE_MANIFEST",
  "version": 2,
  "generatedAtUtc": "2026-09-30T20:46:51.349Z",
  "signatureAlgorithm": "ED25519",
  "digestAlgorithm": "SHA-256",
  "signingKeyId": "fixture-local-only-package-key",
  "signingKeyVersion": "1",
  "manifestFile": "package-manifest.json",
  "manifestSha256": "0dc2471e7b06e4b8a15a0436b54790d7ec648b0bbb60b25e69fd5c4d3f0947e5",
  "publicKeyFile": "package-manifest-public-key.pem",
  "signerProvider": "local-pem",
  "signatureBase64": "Kl7026XL7TBaL1QysNb4STotF1H9ijDT0OLx3c8FKOYdoxlrCbzdlNZVkBmbhakkXUTWFFmZJDG0RrM51QxLCw==",
  "signatureInput": "SHA-256 digest bytes of package-manifest.json signed by the identified Ed25519 signer",
  "note": "This is an Ed25519 cryptographic signature over the SHA-256 digest of package-manifest.json."
}
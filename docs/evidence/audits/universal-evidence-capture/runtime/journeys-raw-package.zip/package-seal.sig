{
  "schema": "PROOVRA_PACKAGE_SEAL_SIGNATURE",
  "version": 1,
  "signedFile": "package-seal.json",
  "digestAlgorithm": "SHA-256",
  "signatureAlgorithm": "ED25519",
  "sealSha256": "67eb79df2964ba9d29b64a86b20da7528ab65b70d6e7813279dd23c300456ad0",
  "signatureBase64": "KsCUXFMz3KTFJ51grA03SEat9MW7/qhFfrK0X86SrKVdo/ep1cpj6b1VPnezSn1jF7mosIE4W/Lz2OqcsbFuAg==",
  "signingKeyId": "fixture-local-only-package-key",
  "signingKeyVersion": "1",
  "signingKeyFingerprint": "8eab16d0cd2d5648ff598ed60351bdb1514eab65cbd87d9e207ad2c2f3d41e98",
  "publicKeyFile": "package-manifest-public-key.pem",
  "signatureInput": "Ed25519 signature over the 32 raw bytes of SHA-256(package-seal.json bytes)"
}
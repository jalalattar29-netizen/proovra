# PROOVRA Qualified-Person Certification Template

Use this template where a jurisdiction or evidentiary posture requires a qualified-person certification for electronic process or system-generated integrity records.

- Evidence ID: 7ccb5a00-7c68-40da-8ccc-d178a44593c3
- Report Version: 1

## Certification

I, ________________________, certify that:

1. I am qualified to describe the PROOVRA evidence-preservation and integrity-verification process.
2. The accompanying package contains the preserved original evidence item(s) or parts, the recorded fingerprint and hash materials, signature verification materials, custody-event records, and associated timestamp/anchoring materials where available.
3. The process used to generate these materials operates in a consistent and documented manner designed to preserve and verify the recorded integrity state of the evidence.
4. The attached report is a presentation artifact and does not replace the preserved originals or the underlying technical materials.
5. The cryptographic methods used, including hashing and digital signatures, are standard publicly verifiable mechanisms designed to support integrity verification.
6. The integrity materials in the verification package can be checked with standard tools; confirming that the signing keys are PROOVRA's requires comparing their fingerprints with those PROOVRA publishes for this record on Public Verify.

Executed on: ________________________
Name: ________________________
Title/Role: ________________________
Signature: ________________________

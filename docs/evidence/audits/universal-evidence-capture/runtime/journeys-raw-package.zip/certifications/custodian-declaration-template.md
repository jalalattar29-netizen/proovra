# PROOVRA Custodian Declaration Template

Use this template with counsel review before court-facing submission.

- Evidence ID: 7ccb5a00-7c68-40da-8ccc-d178a44593c3
- Report Version: 1
- Evidence Title: Digital Evidence Record
- Case ID: Not included
- Jurisdiction: Not included

## Declarant

I, ________________________, declare under penalty of perjury that:

1. I am a records custodian or otherwise qualified person for the PROOVRA evidence record identified above.
2. The attached package was produced from the PROOVRA system in the regular course of the system's operation.
3. The preserved original evidence item(s), cryptographic hash material, signature record, timestamping records, and custody-event records were maintained by the system as part of its regular evidence-preservation workflow.
4. The included report artifact is a reviewer/court presentation summary derived from the preserved record and should be read together with the preserved original and technical materials.
5. The original evidence file(s) referenced in original-linkage.json are the same preserved item(s) used to compute the recorded integrity state reflected in this package.
6. The PROOVRA system is regularly used to preserve digital evidence and generate integrity records as part of a consistent and repeatable process.

Executed on: ________________________
Name: ________________________
Title/Role: ________________________
Signature: ________________________

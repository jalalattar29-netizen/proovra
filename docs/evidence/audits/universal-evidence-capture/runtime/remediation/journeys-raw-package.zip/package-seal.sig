{
  "schema": "PROOVRA_PACKAGE_SEAL_SIGNATURE",
  "version": 1,
  "signedFile": "package-seal.json",
  "digestAlgorithm": "SHA-256",
  "signatureAlgorithm": "ED25519",
  "sealSha256": "c136122352b1f958bc4a2e70e61b011fd22027699a9144d78de8c5f515eabce1",
  "signatureBase64": "anT/WLNovzv9fqVSPb5XGsDhDE9lj4Qu9MFnwQ2Bj3U+AJjp+m+tT7LcrvBWjipA/ojwcuKEa/ZUcsfwWEmoCw==",
  "signingKeyId": "fixture-local-only-package-key",
  "signingKeyVersion": "1",
  "signingKeyFingerprint": "7c61a2800724ce06810535d576084a5824318774df0d40ccc1307868b8326907",
  "publicKeyFile": "package-manifest-public-key.pem",
  "signatureInput": "Ed25519 signature over the 32 raw bytes of SHA-256(package-seal.json bytes)"
}
{
  "schema": "PROOVRA_PACKAGE_SEAL_SIGNATURE",
  "version": 1,
  "signedFile": "package-seal.json",
  "digestAlgorithm": "SHA-256",
  "signatureAlgorithm": "ED25519",
  "sealSha256": "757785966911b11e87fb93c6cfcf0846503c70e1648c77539e328bd30b6ba8d0",
  "signatureBase64": "3PB4NMYFsraa6rtnexjFG624fCp60cFhvz/dNjtCjnzhUvF+WF4VSR0/cNUt+ZobzL3N3I7/NZW0kwf0gN5yAg==",
  "signingKeyId": "fixture-local-only-package-key",
  "signingKeyVersion": "1",
  "signingKeyFingerprint": "7c61a2800724ce06810535d576084a5824318774df0d40ccc1307868b8326907",
  "publicKeyFile": "package-manifest-public-key.pem",
  "signatureInput": "Ed25519 signature over the 32 raw bytes of SHA-256(package-seal.json bytes)"
}
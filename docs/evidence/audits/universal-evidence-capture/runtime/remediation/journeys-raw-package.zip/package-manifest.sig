{
  "schema": "PROOVRA_SIGNED_PACKAGE_MANIFEST",
  "version": 2,
  "generatedAtUtc": "2026-10-01T09:26:24.241Z",
  "signatureAlgorithm": "ED25519",
  "digestAlgorithm": "SHA-256",
  "signingKeyId": "fixture-local-only-package-key",
  "signingKeyVersion": "1",
  "manifestFile": "package-manifest.json",
  "manifestSha256": "2972bf1c7cf18cfa9101653a036e4e4f4168f42d37c24b9477e2d7b03f70af63",
  "publicKeyFile": "package-manifest-public-key.pem",
  "signerProvider": "local-pem",
  "signatureBase64": "2JBKO1v4RMAma2qidICmCMqIutRNsN6FaQHygSj9iAKyCmcxj+sFjI8+B7DN2Isw9eCbgcKAdlMQxBlALHTMDg==",
  "signatureInput": "SHA-256 digest bytes of package-manifest.json signed by the identified Ed25519 signer",
  "note": "This is an Ed25519 cryptographic signature over the SHA-256 digest of package-manifest.json."
}
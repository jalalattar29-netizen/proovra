{
  "schema": "PROOVRA_SIGNED_PACKAGE_MANIFEST",
  "version": 2,
  "generatedAtUtc": "2026-10-01T06:01:18.909Z",
  "signatureAlgorithm": "ED25519",
  "digestAlgorithm": "SHA-256",
  "signingKeyId": "fixture-local-only-package-key",
  "signingKeyVersion": "1",
  "manifestFile": "package-manifest.json",
  "manifestSha256": "72a24954b70dfa5e2a3bd0719ecc9084de5daec4ddca8c6e47dbc16ed4c37a7f",
  "publicKeyFile": "package-manifest-public-key.pem",
  "signerProvider": "local-pem",
  "signatureBase64": "FfMBWdbF37AFYMhpBSp/5p8iNLiTPiqd5UKuxE6wlJ+6iQNqxSiyvXXlMl8q549vEvYu4su0EWbVVHqzGFzgAQ==",
  "signatureInput": "SHA-256 digest bytes of package-manifest.json signed by the identified Ed25519 signer",
  "note": "This is an Ed25519 cryptographic signature over the SHA-256 digest of package-manifest.json."
}
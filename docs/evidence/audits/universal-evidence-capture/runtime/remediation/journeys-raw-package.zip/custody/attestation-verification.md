# Detached Custody Attestation Verification (External)

**This file is bundled inside the Verification Package as `custody/attestation-verification.md`.**

## 1. What you receive

- `custody/attestations.json` — the bounded attestation set for this evidence's custody events.
- `signers/signer-registry-snapshot.json` — the signer state as of package generation.
- Existing package files (`evidence/`, `package-manifest.json`, `package-checksums.json`, etc.) are UNCHANGED by P3.1.1.

## 2. Verifying an attestation

For each entry in `attestations`:

1. Locate the matching custody event row in the package (path varies by package mode; see `package-manifest.json`).
2. Reconstruct the canonical payload using ONLY the immutable fields:
   `{ custodyEventId, evidenceId, eventType, atUtc, sequence, prevEventHash, eventHash }`.
3. JSON-canonicalise (sorted keys, no whitespace) and compute SHA-256.
4. Compare against `canonicalPayloadHash`.
5. Verify the signature using the signer's public material reference
   (see `signers/signer-registry-snapshot.json` for the reference; `provider=aws_kms`
   means the verifier needs the KMS public key, `provider=local_pem` means the verifier
   needs the Ed25519 PEM published by the operator).

## 3. Bounded outcome model

Any verifier that follows this procedure MUST report exactly one of the bounded outcomes:

- `verified`
- `missing_attestation`
- `signature_invalid`
- `payload_hash_mismatch`
- `signer_unavailable`
- `unsupported_algorithm`
- `not_applicable`

## 4. Relationship to other signature surfaces

| Surface | What it proves | What it does NOT prove |
| --- | --- | --- |
| Report PDF signature | The PDF bytes were signed by the recorded signer at the recorded time. | Authorship or admissibility of the underlying evidence. |
| Package manifest signature | `package-manifest.json` was signed at the recorded time. | That every file in the ZIP is independently verifiable. |
| TSA timestamp | A trusted third party witnessed the digest at the recorded time. | The content's authenticity. |
| OTS anchor | The digest was anchored to Bitcoin's blockchain. | Anything about the digest's source or content. |
| **Custody attestation** | The recorded signer signed a hash of the canonical custody payload. | Operator identity, authorisation, or evidence authenticity. |

## 5. Honest limitations

- This is NOT a legal-admissibility surface. Attestations carry cryptographic continuity from the recorded signer, nothing more.
- Attestations require the signer's public material to remain published. If the operator destroys the public key after rotation, attestations signed by that key become unverifiable.
- Missing attestations are recorded honestly in `missingAttestations`. Partial coverage is NOT silently hidden.
- Old packages generated before P3.1.1 do NOT contain attestation files. Their absence is not a verification failure.

PROOVRA Evidence Verification Package

PACKAGE OVERVIEW

This package allows independent verification of the recorded digital evidence state.


Evidence ID: 195c982c-1e02-44a5-aed8-699c884f2f3c
Report Version: 1
Signing Key ID: fixture-local-only-signing-key
Signing Key Version: 1
Reviewer Evidence Type: Photo Evidence
Raw Evidence Type Enum: PHOTO
Evidence Structure: Single evidence item

Verification Profile: FORENSIC_INTEGRITY
Verification Status Note: Integrity materials may be present even when the record still requires legal or reviewer assessment.

FILES INCLUDED

Original evidence file
The original uploaded evidence item is included at the root of this package.

fingerprint.json
Canonical fingerprint used to generate the signature. This is raw, immutable signed technical material: its "type" field is a low-level canonical enum fixed at capture (e.g. DOCUMENT, even for a mixed-media set) — NOT the reviewer-facing evidence classification. See reviewerEvidenceTypeLabel in canonical-record.json or the report's "Evidence Structure" row (e.g. "Mixed media package").

signature.txt
Ed25519 signature of the fingerprint hash material.

timestamp.tsr
Not included in this package. RFC3161 timestamp status: NOT_RECORDED. Integrity verification still relies on hashes, digital signature, preserved originals, custody continuity, and any available anchoring material.

public-key.pem
Public key used to verify the signature.

custody.json
Chain of custody events recorded by the system. Each event's eventHash can be recomputed from this file: eventHash = lowercase hex SHA-256 of the UTF-8 canonical JSON of {"v":1,"evidenceId":<Evidence ID>,"sequence":<sequence>,"eventType":<eventType>,"atUtc":<atUtc>,"payload":<payload, or null>,"prevEventHash":<prevEventHash, or null>}. Canonical JSON: object keys sorted by code point at every level, no whitespace, strings and numbers as JSON.stringify writes them. Use "payload" exactly as it appears; "presentationPayload", where present, is a reader-friendly relabelling and is not part of the hash. Each event's prevEventHash equals the previous event's eventHash.

anchor.json
Included in this package. Status: OpenTimestamps unavailable.

package-manifest.json
Package metadata describing the verification bundle.

package-manifest.sig
Ed25519 signature record for package-manifest.json.

package-checksums.json
SHA-256 checksum manifest for packaged files.

case-metadata.json
Case, matter, workspace, retention, and reviewer context when available.

capture-context.json
Included when signed capture-location metadata exists for the evidence record.

map-preview.png
Optional deterministic location preview derived from capture-context.json for reviewer-facing context only.

audit-access-report.json
Reviewer-friendly access and audit activity summary.

integrity-summary.json
High-level package integrity profile.

trust-decision.json
Enterprise trust decision summary aligned with the PDF report decision model.

canonical-record.json
Single self-describing snapshot of every canonical lifecycle material (evidence record, fingerprint, part index, custody snapshot, identity snapshot, timestamp state, storage state, OTS state with the honesty rule applied, trust decision, media intelligence snapshot, legal boundary). Schema: proovra.canonical-record/v1. Every material inside carries snapshotSemantics = "package-snapshot-only". Reviewers may read this single file to inspect the package-snapshot truth without re-aggregating per-artifact files.

original-linkage.json
Links the included file(s), storage preservation details, and report artifact back to the preserved original record.

duplicate-digests.json
Lists any packaged evidence files that share the same SHA-256 digest.

forensic-custody.json
Integrity-relevant system lifecycle events separated from later reviewer access activity.

access-activity.json
Viewer and package-access activity that should not be confused with forensic custody.

review-artifact-boundaries.json
Explains which artifact is the preserved original, which is the court/report artifact, and which files are reviewer representations.

reviewer-readiness-checklist.json
Structured readiness checklist describing what is present versus what still requires human/legal completion.

certifications/
Templates and declarations to support custodian or qualified-person certification workflows.

reports/
Includes the generated PROOVRA verification report bundled with this package.

CUSTODY CHAIN INTERPRETATION

custody.json contains every custody event recorded for this record up to and including the package's own issuance events, as stored and hashed.
forensic-custody.json contains a curated subset of integrity-relevant events used for forensic review.
access-activity.json contains access, viewing, download, and verification activity that is not part of the forensic custody chronology shown in the PDF report.
It is a package access snapshot at generation time. Current live access activity may increase later on the verification page.

Sequence numbers reflect the original immutable event log. Gaps in forensic views may appear where non-forensic events are excluded.

HOW TO VERIFY

1) Extract the package.
2) Verify the seal (this package is sealed, format 5):
   a. SHA-256 of package-seal.json must equal sealSha256 in package-seal.sig.
   b. signatureBase64 in package-seal.sig must verify with
      package-manifest-public-key.pem, as its signatureAlgorithm and
      signatureInput describe.
   c. The SHA-256 fingerprint of that key (DER SubjectPublicKeyInfo) must equal
      signingKeyFingerprint in package-seal.sig AND the seal key fingerprint
      PROOVRA shows for this package on the record's Public Verify page. A key
      found only inside a package proves nothing by itself: anyone can re-seal
      an altered package with their own key. Public Verify also shows the
      SHA-256 of the exact package file PROOVRA issued.
   NOTE: this record was NOT published for public verification when this
   package was assembled, so its Public Verify page does not answer yet. Ask
   the record's owner to publish it and share a verification link; until then
   the seal key fingerprint and the package SHA-256 cannot be confirmed from
   outside this package.
   d. SHA-256 of package-checksums.json must equal checksumsSha256 in
      package-seal.json; every file must match its line in
      package-checksums.json, and no file may exist outside it other than
      package-checksums.json, package-seal.json and package-seal.sig.
   e. The report named by reportFile must hash to reportSha256.
   package-manifest.sig covers package-manifest.json only; it does not cover
   the report or the checksum index.
   For live integrity and current-trust status, open the PROOVRA Public Verify
   page referenced in the report.
3) Review fingerprint.json.
4) Calculate SHA-256 hash of the included evidence file(s).
5) Compare computed hashes against original-linkage.json, fingerprint.json, and package-checksums.json.

6) Verify signature.txt as an Ed25519 signature over the 32 raw bytes of fingerprintHash (hex-decoded) with public-key.pem, and check that public-key.pem is the evidence signing key PROOVRA publishes for this record on Public Verify (a key found only inside the package vouches for nothing by itself).
7) Verify the RFC3161 timestamp token using timestamp verification tools, if included.
8) Review custody.json and, where present, anchor.json.
9) Review capture-context.json and map-preview.png, if present, as contextual device/browser-reported metadata only.
10) Use original-linkage.json to tie every included file and the bundled report back to the preserved record.
11) Complete the certification templates inside certifications/ before using this package as a court-facing packet.

ANCHOR STATUS

anchor.json is included in this package.
OpenTimestamps proof present; Bitcoin anchoring pending.
Recheck anchoring later if independent Bitcoin anchoring is required.
This anchoring layer is independent from RFC 3161 timestamping.

EVIDENCE CONTAINER BOUNDARY

This package verifies the exported evidence container.
It does not represent the current live server state.
Use Public Verify to inspect the current live state.

LEGAL NOTE

This package supports integrity verification of the recorded evidence state.
It does not independently establish authorship, truthfulness, legal admissibility,
or probative weight. Court-facing use typically also requires a custodian or qualified-person declaration.

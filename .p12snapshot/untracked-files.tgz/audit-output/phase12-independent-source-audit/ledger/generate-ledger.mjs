#!/usr/bin/env node
/**
 * PHASE 12 REMEDIATION — CORRECTIVE PASS, STEP 3 (2026-08-06).
 *
 * THE LEDGER AUTHORITY.
 *
 * Why this exists
 * ---------------
 * The previous remediation report contradicted itself in two arithmetic ways
 * (C1 and C2 in the corrective mandate), and both had the SAME cause: scalar
 * counts were MAINTAINED BY HAND in prose, next to a table of rows, and the
 * two drifted. A hand-written "Nine of nineteen" cannot be wrong-proof; a
 * count DERIVED from the rows can be.
 *
 * So this script is the only thing permitted to state a count. It reads
 * `rows.json`, refuses a malformed row set, derives every scalar, and emits
 * both a machine-readable `ledger.json` and a human `ledger.md`. Nothing
 * downstream may hard-code a total.
 *
 * What it refuses (each is an explicit exit-1 condition)
 * -----------------------------------------------------
 *   * duplicate IDs
 *   * missing IDs (the canonical 25 are pinned below)
 *   * invented IDs (anything outside the canonical set)
 *   * a VERIFIED_CLOSURE row counted as an actionable defect
 *   * an UNKNOWN row silently promoted to a PASS disposition
 *   * a row whose finalDisposition is FIXED without source evidence
 *   * a row claiming runtime/migration/browser verification with no
 *     evidence reference
 *   * counts that do not conserve: fixed + remaining + closures + unknown
 *     must equal the row count
 *
 * The canonical ID set is pinned as DATA, not derived from the file it
 * validates — otherwise a dropped row would validate itself away.
 */

import { readFileSync, writeFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const HERE = path.dirname(fileURLToPath(import.meta.url));

/**
 * The 25 canonical rows of the normalized Phase-12 ledger, pinned so a
 * dropped or invented row is detectable. Severity here is the NORMALIZED
 * severity agreed in Step 0 of the previous pass.
 */
const CANONICAL_ROWS = Object.freeze({
  "SEC-001": "CRITICAL",
  "ARCH-005": "HIGH",
  "AUTH-001": "HIGH",
  "AUTH-002": "HIGH",
  "AUTH-003": "HIGH",
  "AUTH-004": "MEDIUM",
  "AUTH-005": "MEDIUM",
  "COMM-001": "MEDIUM",
  "ARCH-001": "MEDIUM",
  "ARCH-002": "MEDIUM",
  "ARCH-003": "MEDIUM",
  "DB-010": "MEDIUM",
  "MOBILE-001": "MEDIUM",
  "INFRA-001": "LOW",
  "LEGACY-003": "LOW",
  "LEGACY-001": "LOW",
  "COMM-002": "LOW",
  "WEB-002": "LOW",
  "ARCH-004": "LOW",
  "DB-011": "VERIFIED_CLOSURE",
  "WEB-001": "VERIFIED_CLOSURE",
  "UNK-001": "UNKNOWN_BLOCKED",
  "UNK-002": "UNKNOWN_BLOCKED",
  "UNK-003": "UNKNOWN_BLOCKED",
  "UNK-004": "UNKNOWN_BLOCKED",
});

const ACTIONABLE_SEVERITIES = ["CRITICAL", "HIGH", "MEDIUM", "LOW"];

/** Dispositions that assert the defect is gone. */
const CLOSED_DISPOSITIONS = new Set(["FIXED_VERIFIED"]);
/** Dispositions that assert the row still carries work. */
const OPEN_DISPOSITIONS = new Set([
  "OPEN_NOT_STARTED",
  "OPEN_PARTIAL",
  "FIXED_UNVERIFIED",
  "REOPENED",
]);
/** Non-defect dispositions. */
const CLOSURE_DISPOSITIONS = new Set(["VERIFIED_CLOSURE_RETAINED"]);
const UNKNOWN_DISPOSITIONS = new Set([
  "UNKNOWN_RESOLVED_LOCAL",
  "UNKNOWN_OWNER_PENDING",
  "UNKNOWN_STILL_BLOCKED",
]);

const VERIFICATION_STATES = new Set([
  "PASS",
  "FAIL",
  "PARTIAL",
  "NOT_APPLICABLE",
  "NOT_EXECUTED",
]);

function fail(problems) {
  process.stderr.write("\nLEDGER REFUSED — the row set is not admissible:\n");
  for (const p of problems) process.stderr.write(`  * ${p}\n`);
  process.stderr.write("\nNo counts were emitted. Fix rows.json.\n");
  process.exit(1);
}

function main() {
  const rowsPath = path.join(HERE, "rows.json");
  const rows = JSON.parse(readFileSync(rowsPath, "utf8"));
  const problems = [];

  if (!Array.isArray(rows)) fail(["rows.json must be an array of row objects."]);

  // ---- structural admissibility -------------------------------------------
  const seen = new Map();
  for (const r of rows) {
    if (!r || typeof r.id !== "string") {
      problems.push("a row has no string `id`.");
      continue;
    }
    if (seen.has(r.id)) problems.push(`duplicate id: ${r.id}`);
    seen.set(r.id, r);
    if (!(r.id in CANONICAL_ROWS)) problems.push(`invented id (not in the canonical 25): ${r.id}`);
  }
  for (const id of Object.keys(CANONICAL_ROWS)) {
    if (!seen.has(id)) problems.push(`missing id: ${id}`);
  }

  const REQUIRED_FIELDS = [
    "id",
    "originalSeverity",
    "normalizedSeverity",
    "prePassDisposition",
    "claimedRemediationFiles",
    "sourceVerified",
    "runtimeVerified",
    "migrationVerified",
    "browserVerified",
    "remainingRisk",
    "finalDisposition",
    "evidenceReferences",
  ];

  for (const r of rows) {
    if (!r?.id) continue;
    for (const f of REQUIRED_FIELDS) {
      if (!(f in r)) problems.push(`${r.id}: missing required field \`${f}\``);
    }
    if (r.normalizedSeverity !== CANONICAL_ROWS[r.id]) {
      problems.push(
        `${r.id}: normalizedSeverity "${r.normalizedSeverity}" disagrees with the pinned canonical severity "${CANONICAL_ROWS[r.id]}"`,
      );
    }
    for (const f of ["sourceVerified", "runtimeVerified", "migrationVerified", "browserVerified"]) {
      if (r[f] !== undefined && !VERIFICATION_STATES.has(r[f])) {
        problems.push(`${r.id}: ${f} has invalid state "${r[f]}"`);
      }
    }
    if (!Array.isArray(r.evidenceReferences)) {
      problems.push(`${r.id}: evidenceReferences must be an array`);
    }
    if (!Array.isArray(r.claimedRemediationFiles)) {
      problems.push(`${r.id}: claimedRemediationFiles must be an array`);
    }
  }

  // ---- semantic admissibility ---------------------------------------------
  for (const r of rows) {
    if (!r?.id) continue;
    const sev = CANONICAL_ROWS[r.id];
    const d = r.finalDisposition;

    const known =
      CLOSED_DISPOSITIONS.has(d) ||
      OPEN_DISPOSITIONS.has(d) ||
      CLOSURE_DISPOSITIONS.has(d) ||
      UNKNOWN_DISPOSITIONS.has(d);
    if (!known) problems.push(`${r.id}: unknown finalDisposition "${d}"`);

    // A VERIFIED_CLOSURE row may never be counted as an actionable defect.
    if (sev === "VERIFIED_CLOSURE" && !CLOSURE_DISPOSITIONS.has(d)) {
      problems.push(
        `${r.id}: is a VERIFIED_CLOSURE but carries a defect disposition "${d}" — a proof of correctness must not be counted as a defect.`,
      );
    }
    if (sev !== "VERIFIED_CLOSURE" && CLOSURE_DISPOSITIONS.has(d)) {
      problems.push(`${r.id}: claims VERIFIED_CLOSURE_RETAINED but is not a closure row.`);
    }

    // An UNKNOWN may never be silently promoted to a PASS/defect disposition.
    if (sev === "UNKNOWN_BLOCKED" && !UNKNOWN_DISPOSITIONS.has(d)) {
      problems.push(
        `${r.id}: is UNKNOWN_BLOCKED but carries "${d}" — an unknown must resolve to an explicit UNKNOWN_* disposition, never be promoted to a pass.`,
      );
    }
    if (sev !== "UNKNOWN_BLOCKED" && UNKNOWN_DISPOSITIONS.has(d)) {
      problems.push(`${r.id}: uses an UNKNOWN_* disposition but is not an unknown row.`);
    }

    // FIXED_VERIFIED demands actual evidence.
    if (CLOSED_DISPOSITIONS.has(d)) {
      if (r.sourceVerified !== "PASS") {
        problems.push(`${r.id}: FIXED_VERIFIED requires sourceVerified=PASS (got "${r.sourceVerified}").`);
      }
      if (!r.evidenceReferences.length) {
        problems.push(`${r.id}: FIXED_VERIFIED with no evidenceReferences.`);
      }
    }
    // A claimed verification must cite evidence.
    for (const f of ["runtimeVerified", "migrationVerified", "browserVerified"]) {
      if (r[f] === "PASS" && !r.evidenceReferences.length) {
        problems.push(`${r.id}: ${f}=PASS with no evidenceReferences.`);
      }
    }
  }

  if (problems.length) fail(problems);

  // ---- DERIVED counts. Nothing below is hand-maintained. -------------------
  const bySeverity = {};
  for (const s of [...ACTIONABLE_SEVERITIES, "VERIFIED_CLOSURE", "UNKNOWN_BLOCKED"]) {
    bySeverity[s] = { total: 0, closed: 0, open: 0 };
  }
  const fixed = [];
  const remaining = [];
  const closures = [];
  const unknowns = [];

  for (const r of rows) {
    const sev = CANONICAL_ROWS[r.id];
    const d = r.finalDisposition;
    bySeverity[sev].total += 1;
    if (CLOSED_DISPOSITIONS.has(d)) {
      bySeverity[sev].closed += 1;
      fixed.push(r.id);
    } else if (OPEN_DISPOSITIONS.has(d)) {
      bySeverity[sev].open += 1;
      remaining.push(r.id);
    } else if (CLOSURE_DISPOSITIONS.has(d)) {
      closures.push(r.id);
    } else {
      unknowns.push(r.id);
    }
  }

  const actionableTotal = ACTIONABLE_SEVERITIES.reduce((n, s) => n + bySeverity[s].total, 0);
  const actionableClosed = ACTIONABLE_SEVERITIES.reduce((n, s) => n + bySeverity[s].closed, 0);
  const actionableOpen = ACTIONABLE_SEVERITIES.reduce((n, s) => n + bySeverity[s].open, 0);

  // ---- CONSERVATION. The check the previous report failed. -----------------
  const conservationProblems = [];
  if (actionableClosed + actionableOpen !== actionableTotal) {
    conservationProblems.push(
      `actionable conservation broken: closed(${actionableClosed}) + open(${actionableOpen}) != total(${actionableTotal})`,
    );
  }
  const grand = fixed.length + remaining.length + closures.length + unknowns.length;
  if (grand !== rows.length) {
    conservationProblems.push(`row conservation broken: dispositions(${grand}) != rows(${rows.length})`);
  }
  if (rows.length !== Object.keys(CANONICAL_ROWS).length) {
    conservationProblems.push(
      `row count ${rows.length} != canonical ${Object.keys(CANONICAL_ROWS).length}`,
    );
  }
  if (conservationProblems.length) fail(conservationProblems);

  const ledger = {
    generatedBy: "audit-output/phase12-independent-source-audit/ledger/generate-ledger.mjs",
    note: "Every scalar in this file is DERIVED from rows.json. No count is hand-maintained.",
    rowCount: rows.length,
    actionable: {
      total: actionableTotal,
      closed: actionableClosed,
      open: actionableOpen,
      bySeverity: Object.fromEntries(ACTIONABLE_SEVERITIES.map((s) => [s, bySeverity[s]])),
    },
    verifiedClosures: { total: bySeverity.VERIFIED_CLOSURE.total, ids: closures },
    unknownBlocked: {
      total: bySeverity.UNKNOWN_BLOCKED.total,
      ids: unknowns,
      byDisposition: unknowns.reduce((acc, id) => {
        const d = seen.get(id).finalDisposition;
        acc[d] = (acc[d] ?? 0) + 1;
        return acc;
      }, {}),
    },
    fixedIds: fixed,
    remainingIds: remaining,
    conservationEquation: `${actionableClosed} fixed + ${actionableOpen} remaining = ${actionableTotal} actionable; + ${closures.length} closures + ${unknowns.length} unknown = ${rows.length} rows`,
    verificationCoverage: {
      sourceVerifiedPass: rows.filter((r) => r.sourceVerified === "PASS").length,
      runtimeVerifiedPass: rows.filter((r) => r.runtimeVerified === "PASS").length,
      migrationVerifiedPass: rows.filter((r) => r.migrationVerified === "PASS").length,
      browserVerifiedPass: rows.filter((r) => r.browserVerified === "PASS").length,
      runtimeNotExecuted: rows.filter((r) => r.runtimeVerified === "NOT_EXECUTED").length,
    },
    rows,
  };

  writeFileSync(path.join(HERE, "ledger.json"), `${JSON.stringify(ledger, null, 2)}\n`);

  // ---- human rendering, also derived --------------------------------------
  const md = [];
  md.push("# Phase 12 — Corrective-Pass Ledger (GENERATED)");
  md.push("");
  md.push("> Generated by `generate-ledger.mjs` from `rows.json`.");
  md.push("> **Every number below is derived from the rows.** Do not edit this file;");
  md.push("> edit `rows.json` and regenerate. The generator refuses a row set that");
  md.push("> duplicates, drops, invents, double-counts, or silently promotes a row.");
  md.push("");
  md.push("## Derived counts");
  md.push("");
  md.push("```text");
  md.push(`rows                       ${ledger.rowCount}`);
  md.push(`actionable total           ${ledger.actionable.total}`);
  md.push(`actionable closed          ${ledger.actionable.closed}`);
  md.push(`actionable open            ${ledger.actionable.open}`);
  for (const s of ACTIONABLE_SEVERITIES) {
    const b = ledger.actionable.bySeverity[s];
    md.push(`  ${s.padEnd(9)} total ${b.total}  closed ${b.closed}  open ${b.open}`);
  }
  md.push(`verified closures          ${ledger.verifiedClosures.total}`);
  md.push(`unknown blocked            ${ledger.unknownBlocked.total}`);
  for (const [d, n] of Object.entries(ledger.unknownBlocked.byDisposition)) {
    md.push(`  ${d.padEnd(24)} ${n}`);
  }
  md.push("");
  md.push(`conservation: ${ledger.conservationEquation}`);
  md.push("```");
  md.push("");
  md.push("## Verification coverage (rows, not assertions)");
  md.push("");
  md.push("```text");
  for (const [k, v] of Object.entries(ledger.verificationCoverage)) {
    md.push(`${k.padEnd(26)} ${v}`);
  }
  md.push("```");
  md.push("");
  md.push("## Rows");
  md.push("");
  md.push("| id | sev | pre-pass | src | runtime | migration | browser | final | residual risk |");
  md.push("|---|---|---|---|---|---|---|---|---|");
  for (const r of rows) {
    md.push(
      `| ${r.id} | ${r.normalizedSeverity} | ${r.prePassDisposition} | ${r.sourceVerified} | ${r.runtimeVerified} | ${r.migrationVerified} | ${r.browserVerified} | **${r.finalDisposition}** | ${r.remainingRisk} |`,
    );
  }
  md.push("");
  writeFileSync(path.join(HERE, "ledger.md"), `${md.join("\n")}\n`);

  process.stdout.write(`${JSON.stringify(
    {
      ok: true,
      rowCount: ledger.rowCount,
      actionable: { total: actionableTotal, closed: actionableClosed, open: actionableOpen },
      bySeverity: ledger.actionable.bySeverity,
      verifiedClosures: ledger.verifiedClosures.total,
      unknownBlocked: ledger.unknownBlocked,
      conservationEquation: ledger.conservationEquation,
      verificationCoverage: ledger.verificationCoverage,
    },
    null,
    2,
  )}\n`);
}

main();

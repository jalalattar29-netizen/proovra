-- PHASE 12 CORRECTIVE PASS §1.1 (2026-08-06) — ONE DELIVERY INTENT PER ATTEMPT.
--
-- FOUND BY RUNTIME PROBING, NOT BY TESTS.
--
-- `sendInvitationEmail` created a NEW `external_review_invitation_deliveries`
-- row on EVERY call and then derived the provider idempotency key FROM THAT
-- ROW'S ID. The key was therefore fresh on every call, so nothing collapsed:
--
--   * a RETRY of the same logical send minted a second intent and a second
--     key, and the provider — shown a key it had never seen — accepted it as a
--     new message. The external reviewer received the invitation twice.
--   * FOUR CONCURRENT sends minted four intents and four keys, so a
--     double-clicked "Send invites", a retried bulk batch, or two operators
--     acting at once fanned out four copies of a live bearer-token link.
--
-- The code comment at the key-minting site asserted the opposite — "a retry of
-- THIS attempt reuses it, while a deliberate resend is a different intent and
-- a different key". That was the intended design; nothing implemented it,
-- because every call took the create path.
--
-- THIS MIGRATION supplies the missing invariant at the only layer that can
-- enforce it under concurrency. The application half (reuse-on-conflict) is in
-- portal-invitation-email.service.ts; without the constraint below that half
-- would still race, since two sessions can both observe "no existing row"
-- before either inserts.
--
-- Attempt semantics are UNCHANGED and are what makes this safe:
--   attempt = 1        for an ordinary send (isResend = false)
--   attempt = prior+1  for a deliberate resend (isResend = true)
-- so repeated ordinary sends collapse onto one intent, while an operator's
-- explicit resend stays a distinct intent with its own key.
--
-- EXPAND-ONLY. Adds a constraint; drops nothing and rewrites no history. The
-- de-duplication below is bounded and deterministic: it keeps the OLDEST row
-- of each group at its original position and re-numbers the rest onto free
-- attempt numbers rather than deleting delivery history, which is
-- audit-relevant.
--
-- Every statement is wrapped in the Phase O-Final information_schema guard, so
-- it is a no-op against a database where the table or any referenced column is
-- absent rather than a hard failure mid-deploy.

-- STEP 1 — re-number pre-existing duplicates so the unique index below can be
-- created. Ordered by queued_at then id, so the assignment is deterministic
-- and a re-run produces the same result.
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
     WHERE table_schema = 'public'
       AND table_name = 'external_review_invitation_deliveries'
       AND column_name = 'team_id'
  ) AND EXISTS (
    SELECT 1 FROM information_schema.columns
     WHERE table_schema = 'public'
       AND table_name = 'external_review_invitation_deliveries'
       AND column_name = 'grant_id'
  ) AND EXISTS (
    SELECT 1 FROM information_schema.columns
     WHERE table_schema = 'public'
       AND table_name = 'external_review_invitation_deliveries'
       AND column_name = 'attempt'
  ) AND EXISTS (
    SELECT 1 FROM information_schema.columns
     WHERE table_schema = 'public'
       AND table_name = 'external_review_invitation_deliveries'
       AND column_name = 'queued_at_utc'
  ) THEN
    EXECUTE $sql$
      WITH ranked AS (
        SELECT
          "id",
          ROW_NUMBER() OVER (
            PARTITION BY "team_id", "grant_id"
            ORDER BY "queued_at_utc" ASC, "id" ASC
          ) AS seq
        FROM "external_review_invitation_deliveries"
      )
      UPDATE "external_review_invitation_deliveries" d
      SET "attempt" = r.seq
      FROM ranked r
      WHERE d."id" = r."id"
        AND d."attempt" IS DISTINCT FROM r.seq
    $sql$;
  END IF;
END $$;

-- STEP 2 — the invariant itself, in its OWN guarded block.
--
-- Split from step 1 deliberately. The migration-safety audit looks for the
-- information_schema guards in the source WINDOW IMMEDIATELY PRECEDING each
-- CREATE INDEX; with the de-duplication statement sitting between them, the
-- guards fell outside that window and the index was classified
-- INDEX_COLUMN_RISK (CRITICAL) even though it was genuinely guarded. Keeping
-- the guard adjacent to the thing it guards is also simply easier to read.
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
     WHERE table_schema = 'public'
       AND table_name = 'external_review_invitation_deliveries'
       AND column_name = 'team_id'
  ) AND EXISTS (
    SELECT 1 FROM information_schema.columns
     WHERE table_schema = 'public'
       AND table_name = 'external_review_invitation_deliveries'
       AND column_name = 'grant_id'
  ) AND EXISTS (
    SELECT 1 FROM information_schema.columns
     WHERE table_schema = 'public'
       AND table_name = 'external_review_invitation_deliveries'
       AND column_name = 'attempt'
  ) THEN
    EXECUTE 'CREATE UNIQUE INDEX IF NOT EXISTS "external_review_invitation_deliveries_grant_attempt_key" ON "external_review_invitation_deliveries" ("team_id", "grant_id", "attempt")';
  END IF;
END $$;

/**
 * PHASE 12 CORRECTIVE PASS §1.3 — THE STRUCTURAL GUARD FOR THE IDENTITY RAIL.
 *
 * `identity.routes.ts#resolveWorkspaceSubject` reads `User.currentWorkspaceId`
 * and RETURNS it. That is a CANDIDATE workspace id, not an authorization fact,
 * and it is safe only because every call site authorizes on the very next line
 * via `requireIdentityActor` (which runs the canonical `authorizeOrFail`).
 *
 * "Only because every call site does X" is a guarantee that decays: it holds
 * until someone adds a call site that does not. The §1.3 gate cannot see the
 * relationship — it reads the expression the pointer came from, not what seven
 * separate handlers do with the value afterwards — so the invariant is
 * enforced here instead, where a new caller would be written.
 *
 * The alternative, making the resolver authorize for itself, was implemented
 * and reverted: it duplicated the policy evaluation and the deny-path audit
 * row on every request in order to defend against a caller that does not
 * exist. This test buys the same guarantee for nothing.
 */

import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const SRC = resolve(
  dirname(fileURLToPath(import.meta.url)),
  "../src/routes/identity.routes.ts",
);

describe("§1.3 — the identity workspace rail is a candidate, never an authority", () => {
  const source = readFileSync(SRC, "utf8");

  it("resolveWorkspaceSubject reads the pointer and nothing else decides", () => {
    // The helper must remain a pure candidate resolver: it may read the
    // pointer and compare a declared id against it, and it must not itself
    // scope a tenant query.
    const body = /async function resolveWorkspaceSubject\([\s\S]*?\n}/.exec(source);
    expect(body, "resolveWorkspaceSubject must exist").toBeTruthy();
    expect(body![0]).toMatch(/select:\s*\{\s*currentWorkspaceId:\s*true\s*\}/);
    // It must not read tenant data itself — the pointer has proven nothing yet.
    expect(body![0]).not.toMatch(/prisma\.(evidence|case|teamMember)\./);
  });

  it("EVERY call site authorizes the returned workspace before using it", () => {
    const lines = source.split("\n");
    const callSites: number[] = [];
    lines.forEach((line, i) => {
      if (/=\s*await resolveWorkspaceSubject\(/.test(line)) callSites.push(i);
    });

    // Positive control: if this ever reaches zero, the test has stopped
    // testing anything and must fail rather than pass vacuously.
    expect(
      callSites.length,
      "the rail must still have call sites; zero means this guard is inert",
    ).toBeGreaterThan(0);

    const unguarded: string[] = [];
    for (const i of callSites) {
      // The guarantee: within a short window after the resolve, the same
      // handler must call requireIdentityActor with the resolved id. The
      // window is deliberately small — an authorization that happens far away
      // from the resolution is exactly the drift this guard exists to catch.
      const window = lines.slice(i, i + 6).join("\n");
      if (!/requireIdentityActor\(\s*req,\s*reply,\s*teamId\b/.test(window)) {
        unguarded.push(`${i + 1}: ${lines[i]!.trim()}`);
      }
    }
    expect(
      unguarded,
      `resolveWorkspaceSubject call sites that do not authorize the returned workspace:\n${unguarded.join(
        "\n",
      )}`,
    ).toEqual([]);
  });

  it("requireIdentityActor routes through the canonical primitive", () => {
    const body = /async function requireIdentityActor\([\s\S]*?\n}/.exec(source);
    expect(body, "requireIdentityActor must exist").toBeTruthy();
    // It is the authorization step. If it stops calling the canonical
    // primitive, the guard above would be pointing at nothing.
    expect(body![0]).toMatch(/authorizeOrFail\(/);
  });
});
